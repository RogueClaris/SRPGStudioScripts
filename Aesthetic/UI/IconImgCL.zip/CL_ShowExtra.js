var ShowExtrasCL0 = ExtraControl.isExtraDisplayable;
ExtraControl.isExtraDisplayable = function(){
	var result = ShowExtrasCL0.call(this);
	if (this.isRecollectionDisplayable()){
		return true;
	}
	return result;
}