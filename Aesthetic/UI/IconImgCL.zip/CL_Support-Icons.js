//put the folder IconImgCL in your project's Material folder.
//that is all you have to do to use this plugin with your supports.
//additional editing is available.
(function(){
var IMG_NAME_CL = ["Bronze.png", "Silver.png", "Gold.png", "Mithril.png"] //edit this to change to the images you put in your Material folder.
var ICON_SIZE_CL = [[24, 24], [24, 24], [24, 24], [24, 24]] //edit this to change the icons' width and height, in that order
SupportRankScrollbar.drawScrollContent = function(x, y, object, isSelect, index) {
	var alpha = this.isEventEnabled(object) ? 255 : 128;
	var icon = root.getMaterialManager().createImage("IconImgCL", IMG_NAME_CL[index])
	icon.setAlpha(alpha)
	x = (532 + (index * ICON_SIZE_CL[index][0]) + 5)
	icon.drawStretchParts(x, y, ICON_SIZE_CL[index][0], ICON_SIZE_CL[index][1], 0, 0, icon.getWidth(), icon.getHeight())
}
})();